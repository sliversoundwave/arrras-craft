# ArrasCraft.io

Arras.io private sever hosted by: CancelX

**Devolpment team**

`CancelX` (MAIN DEV)

`mse` (DEV of mse's Arras Server [msk](http://arras.surge.sh/#private=msk.glitch.me))

`antelope` (DEV of antelopes arras)

`Ɗคᶇƙツ` (DEV of Dank's Arras, Co-Dev of ACarras)

`Soundwave` (DEV of Soundwave's Arras [soundwave's arras](https://soundwave-arras.glitch.me/))

`AC` (DEV of ACarras)
